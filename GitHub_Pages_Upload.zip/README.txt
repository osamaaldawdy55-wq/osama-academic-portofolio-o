GitHub Pages ePortfolio publishing package

1. Sign in at https://github.com
2. Click + (top right) -> New repository
3. Repository name: com00003-eportfolio
4. Set Public and create the repository
5. Click Add file -> Upload files
6. Upload all three files in this folder (index.html is the website entry page)
7. Click Commit changes
8. Open repository Settings -> Pages
9. Under Build and deployment, choose Deploy from a branch
10. Branch: main; Folder: /(root); click Save
11. Wait a few minutes. Your site will be at:
   https://YOUR-GITHUB-USERNAME.github.io/com00003-eportfolio/
Replace YOUR-GITHUB-USERNAME with your GitHub username.
